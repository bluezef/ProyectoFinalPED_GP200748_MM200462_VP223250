﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FACTURACION
{
    public partial class ventaporEmpleado : Form
    {
        private ConexionBD conexionBD = new ConexionBD();

        public ventaporEmpleado()
        {
            InitializeComponent();
        }

        private void ventaporEmpleado_Load(object sender, EventArgs e)
        {
            CargarVentasPorEmpleado();
        }

        private void CargarVentasPorEmpleado()
        {
            string query = @"SELECT usuarioempleado as Empleado, SUM(Total) as 'Ventas Totales'
                     FROM Venta
                     GROUP BY usuarioempleado;";

            using (var conexion = conexionBD.ObtenerConexion())
            {
                using (var comando = new MySqlCommand(query, conexion))
                {
                    DataTable dt = new DataTable();
                    MySqlDataAdapter adaptador = new MySqlDataAdapter(comando);
                    adaptador.Fill(dt);

                    dgvVentas.DataSource = dt;

                    dgvVentas.Columns["Ventas Totales"].DefaultCellStyle.Format = "C2";
                }
            }
        }

    }

}
