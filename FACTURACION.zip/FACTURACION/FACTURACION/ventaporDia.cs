﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FACTURACION
{
    public partial class ventaporDia : Form
    {
        private ConexionBD conexionBD = new ConexionBD();

        public ventaporDia()
        {
            InitializeComponent();
        }

        private void ventaporDia_Load(object sender, EventArgs e)
        {
            CargarVentasPorDia();
        }

        private void CargarVentasPorDia()
        {
            string query = @"SELECT DATE(FechaVenta) as Fecha, SUM(Total) as VentasTotales
                            FROM Venta
                            GROUP BY DATE(FechaVenta)
                            ORDER BY DATE(FechaVenta);
                            ;";

            using (var conexion = conexionBD.ObtenerConexion())
            {
                using (var comando = new MySqlCommand(query, conexion))
                {
                    DataTable dt = new DataTable();
                    MySqlDataAdapter adaptador = new MySqlDataAdapter(comando);
                    adaptador.Fill(dt);

                    dgvVentas.DataSource = dt;

                    dgvVentas.Columns["VentasTotales"].DefaultCellStyle.Format = "C2";
                    dgvVentas.Columns["Fecha"].DefaultCellStyle.Format = "dd/MM/yyyy";
                }
            }
        }
    }

}
