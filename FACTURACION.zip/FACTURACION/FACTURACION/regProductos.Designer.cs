﻿namespace FACTURACION
{
    partial class regProductos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtdescripcion = new TextBox();
            label4 = new Label();
            cmbcategoria = new ComboBox();
            btnBorrar = new Button();
            btnCerrar = new Button();
            btnRegistrar = new Button();
            txtCantidad = new TextBox();
            txtPrecio = new TextBox();
            txtNombre = new TextBox();
            label7 = new Label();
            label5 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            SuspendLayout();
            // 
            // txtdescripcion
            // 
            txtdescripcion.Location = new Point(386, 399);
            txtdescripcion.Name = "txtdescripcion";
            txtdescripcion.Size = new Size(304, 23);
            txtdescripcion.TabIndex = 35;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            label4.ForeColor = Color.White;
            label4.Location = new Point(249, 399);
            label4.Name = "label4";
            label4.Size = new Size(131, 25);
            label4.TabIndex = 34;
            label4.Text = "Descripcion:";
            // 
            // cmbcategoria
            // 
            cmbcategoria.FormattingEnabled = true;
            cmbcategoria.Location = new Point(386, 262);
            cmbcategoria.Name = "cmbcategoria";
            cmbcategoria.Size = new Size(304, 23);
            cmbcategoria.TabIndex = 33;
            // 
            // btnBorrar
            // 
            btnBorrar.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            btnBorrar.Location = new Point(605, 547);
            btnBorrar.Name = "btnBorrar";
            btnBorrar.Size = new Size(85, 31);
            btnBorrar.TabIndex = 32;
            btnBorrar.Text = "Borrar";
            btnBorrar.UseVisualStyleBackColor = true;
            btnBorrar.Click += btnBorrar_Click;
            // 
            // btnCerrar
            // 
            btnCerrar.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            btnCerrar.Location = new Point(63, 547);
            btnCerrar.Name = "btnCerrar";
            btnCerrar.Size = new Size(82, 31);
            btnCerrar.TabIndex = 31;
            btnCerrar.Text = "Cerrar";
            btnCerrar.UseVisualStyleBackColor = true;
            // 
            // btnRegistrar
            // 
            btnRegistrar.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            btnRegistrar.Location = new Point(702, 547);
            btnRegistrar.Name = "btnRegistrar";
            btnRegistrar.Size = new Size(112, 31);
            btnRegistrar.TabIndex = 30;
            btnRegistrar.Text = "Registrar";
            btnRegistrar.UseVisualStyleBackColor = true;
            btnRegistrar.Click += btnRegistrar_Click;
            // 
            // txtCantidad
            // 
            txtCantidad.Location = new Point(386, 353);
            txtCantidad.Name = "txtCantidad";
            txtCantidad.Size = new Size(304, 23);
            txtCantidad.TabIndex = 29;
            // 
            // txtPrecio
            // 
            txtPrecio.Location = new Point(386, 309);
            txtPrecio.Name = "txtPrecio";
            txtPrecio.Size = new Size(304, 23);
            txtPrecio.TabIndex = 28;
            // 
            // txtNombre
            // 
            txtNombre.Location = new Point(386, 217);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new Size(304, 23);
            txtNombre.TabIndex = 27;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            label7.ForeColor = Color.White;
            label7.Location = new Point(301, 307);
            label7.Name = "label7";
            label7.Size = new Size(79, 25);
            label7.TabIndex = 26;
            label7.Text = "Precio:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            label5.ForeColor = Color.White;
            label5.Location = new Point(146, 355);
            label5.Name = "label5";
            label5.Size = new Size(234, 25);
            label5.TabIndex = 25;
            label5.Text = "Cantidad en inventario:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            label3.ForeColor = Color.White;
            label3.Location = new Point(240, 260);
            label3.Name = "label3";
            label3.Size = new Size(140, 25);
            label3.TabIndex = 24;
            label3.Text = "Clasificación:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            label2.ForeColor = Color.White;
            label2.Location = new Point(287, 212);
            label2.Name = "label2";
            label2.Size = new Size(93, 25);
            label2.TabIndex = 23;
            label2.Text = "Nombre:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 27F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.White;
            label1.Location = new Point(63, 141);
            label1.Name = "label1";
            label1.Size = new Size(317, 40);
            label1.TabIndex = 22;
            label1.Text = "Perfil de producto";
            // 
            // regProductos
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.DarkOliveGreen;
            ClientSize = new Size(900, 718);
            Controls.Add(txtdescripcion);
            Controls.Add(label4);
            Controls.Add(cmbcategoria);
            Controls.Add(btnBorrar);
            Controls.Add(btnCerrar);
            Controls.Add(btnRegistrar);
            Controls.Add(txtCantidad);
            Controls.Add(txtPrecio);
            Controls.Add(txtNombre);
            Controls.Add(label7);
            Controls.Add(label5);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Margin = new Padding(3, 2, 3, 2);
            Name = "regProductos";
            Text = "regProductos";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtdescripcion;
        private Label label4;
        private ComboBox cmbcategoria;
        private Button btnBorrar;
        private Button btnCerrar;
        private Button btnRegistrar;
        private TextBox txtCantidad;
        private TextBox txtPrecio;
        private TextBox txtNombre;
        private Label label7;
        private Label label5;
        private Label label3;
        private Label label2;
        private Label label1;
    }
}