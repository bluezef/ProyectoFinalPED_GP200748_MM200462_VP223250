﻿namespace FACTURACION
{
    partial class MenuPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            panelformularioactivo = new Panel();
            lblogopredmainadm = new Label();
            panelmenulateral = new Panel();
            button2 = new Button();
            btregvent = new Button();
            btayuda = new Button();
            btmiperfil = new Button();
            button1 = new Button();
            btsalir = new Button();
            btregemp = new Button();
            btregprod = new Button();
            panelsubmenumostvent = new Panel();
            btmisvent = new Button();
            btmostventot = new Button();
            btmostventemp = new Button();
            btmostvent = new Button();
            btmostemp = new Button();
            btmostprod = new Button();
            panellogo = new Panel();
            pictureBox1 = new PictureBox();
            contextMenuStrip1 = new ContextMenuStrip(components);
            panelformularioactivo.SuspendLayout();
            panelmenulateral.SuspendLayout();
            panelsubmenumostvent.SuspendLayout();
            panellogo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // panelformularioactivo
            // 
            panelformularioactivo.BackColor = Color.DarkOliveGreen;
            panelformularioactivo.Controls.Add(lblogopredmainadm);
            panelformularioactivo.Dock = DockStyle.Top;
            panelformularioactivo.Location = new Point(291, 0);
            panelformularioactivo.Margin = new Padding(4);
            panelformularioactivo.Name = "panelformularioactivo";
            panelformularioactivo.Size = new Size(908, 754);
            panelformularioactivo.TabIndex = 3;
            panelformularioactivo.Paint += panelformularioactivo_Paint;
            panelformularioactivo.MouseEnter += btmostprod_MouseEnter;
            // 
            // lblogopredmainadm
            // 
            lblogopredmainadm.Anchor = AnchorStyles.Bottom;
            lblogopredmainadm.BackColor = Color.Transparent;
            lblogopredmainadm.Font = new Font("Microsoft Sans Serif", 26.25F, FontStyle.Regular, GraphicsUnit.Point);
            lblogopredmainadm.ForeColor = Color.White;
            lblogopredmainadm.Location = new Point(253, 487);
            lblogopredmainadm.Margin = new Padding(4, 0, 4, 0);
            lblogopredmainadm.Name = "lblogopredmainadm";
            lblogopredmainadm.Size = new Size(426, 118);
            lblogopredmainadm.TabIndex = 1;
            lblogopredmainadm.Text = "Elige una opción ";
            lblogopredmainadm.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // panelmenulateral
            // 
            panelmenulateral.AutoScroll = true;
            panelmenulateral.BackColor = Color.White;
            panelmenulateral.Controls.Add(button2);
            panelmenulateral.Controls.Add(btregvent);
            panelmenulateral.Controls.Add(btayuda);
            panelmenulateral.Controls.Add(btmiperfil);
            panelmenulateral.Controls.Add(button1);
            panelmenulateral.Controls.Add(btsalir);
            panelmenulateral.Controls.Add(btregemp);
            panelmenulateral.Controls.Add(btregprod);
            panelmenulateral.Controls.Add(panelsubmenumostvent);
            panelmenulateral.Controls.Add(btmostvent);
            panelmenulateral.Controls.Add(btmostemp);
            panelmenulateral.Controls.Add(btmostprod);
            panelmenulateral.Controls.Add(panellogo);
            panelmenulateral.Dock = DockStyle.Left;
            panelmenulateral.ForeColor = Color.White;
            panelmenulateral.Location = new Point(0, 0);
            panelmenulateral.Margin = new Padding(4);
            panelmenulateral.Name = "panelmenulateral";
            panelmenulateral.Size = new Size(291, 753);
            panelmenulateral.TabIndex = 2;
            // 
            // button2
            // 
            button2.Dock = DockStyle.Top;
            button2.FlatAppearance.BorderSize = 0;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            button2.ForeColor = Color.DarkOliveGreen;
            button2.Location = new Point(0, 549);
            button2.Margin = new Padding(4);
            button2.Name = "button2";
            button2.Padding = new Padding(11, 0, 0, 0);
            button2.Size = new Size(291, 46);
            button2.TabIndex = 12;
            button2.Text = "Productos por categoría";
            button2.TextAlign = ContentAlignment.MiddleLeft;
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // btregvent
            // 
            btregvent.Dock = DockStyle.Top;
            btregvent.FlatAppearance.BorderSize = 0;
            btregvent.FlatStyle = FlatStyle.Flat;
            btregvent.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            btregvent.ForeColor = Color.DarkOliveGreen;
            btregvent.Location = new Point(0, 503);
            btregvent.Margin = new Padding(4);
            btregvent.Name = "btregvent";
            btregvent.Padding = new Padding(11, 0, 0, 0);
            btregvent.Size = new Size(291, 46);
            btregvent.TabIndex = 11;
            btregvent.Text = "Registrar venta";
            btregvent.TextAlign = ContentAlignment.MiddleLeft;
            btregvent.UseVisualStyleBackColor = true;
            btregvent.Click += btregvent_Click;
            btregvent.MouseEnter += btmostprod_MouseEnter;
            // 
            // btayuda
            // 
            btayuda.Dock = DockStyle.Bottom;
            btayuda.FlatAppearance.BorderSize = 0;
            btayuda.FlatStyle = FlatStyle.Flat;
            btayuda.Font = new Font("Microsoft Sans Serif", 9.749999F, FontStyle.Regular, GraphicsUnit.Point);
            btayuda.ForeColor = Color.DarkOliveGreen;
            btayuda.Location = new Point(0, 617);
            btayuda.Margin = new Padding(4);
            btayuda.Name = "btayuda";
            btayuda.Padding = new Padding(11, 0, 0, 0);
            btayuda.Size = new Size(291, 34);
            btayuda.TabIndex = 9;
            btayuda.Text = "Ayuda";
            btayuda.TextAlign = ContentAlignment.MiddleRight;
            btayuda.UseVisualStyleBackColor = true;
            btayuda.MouseEnter += btmostprod_MouseEnter;
            // 
            // btmiperfil
            // 
            btmiperfil.Dock = DockStyle.Bottom;
            btmiperfil.FlatAppearance.BorderSize = 0;
            btmiperfil.FlatStyle = FlatStyle.Flat;
            btmiperfil.Font = new Font("Microsoft Sans Serif", 9.749999F, FontStyle.Regular, GraphicsUnit.Point);
            btmiperfil.ForeColor = Color.DarkOliveGreen;
            btmiperfil.Location = new Point(0, 651);
            btmiperfil.Margin = new Padding(4);
            btmiperfil.Name = "btmiperfil";
            btmiperfil.Padding = new Padding(11, 0, 0, 0);
            btmiperfil.Size = new Size(291, 34);
            btmiperfil.TabIndex = 10;
            btmiperfil.Text = "Mi perfil";
            btmiperfil.TextAlign = ContentAlignment.MiddleRight;
            btmiperfil.UseVisualStyleBackColor = true;
            btmiperfil.Click += btmiperfil_Click;
            btmiperfil.MouseEnter += btmostprod_MouseEnter;
            // 
            // button1
            // 
            button1.Dock = DockStyle.Bottom;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Microsoft Sans Serif", 9.749999F, FontStyle.Regular, GraphicsUnit.Point);
            button1.ForeColor = Color.DarkOliveGreen;
            button1.Location = new Point(0, 685);
            button1.Margin = new Padding(4);
            button1.Name = "button1";
            button1.Padding = new Padding(11, 0, 0, 0);
            button1.Size = new Size(291, 34);
            button1.TabIndex = 8;
            button1.Text = "Cerrar Sesión";
            button1.TextAlign = ContentAlignment.MiddleRight;
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            button1.MouseEnter += btmostprod_MouseEnter;
            // 
            // btsalir
            // 
            btsalir.Dock = DockStyle.Bottom;
            btsalir.FlatAppearance.BorderSize = 0;
            btsalir.FlatStyle = FlatStyle.Flat;
            btsalir.Font = new Font("Microsoft Sans Serif", 9.749999F, FontStyle.Regular, GraphicsUnit.Point);
            btsalir.ForeColor = Color.DarkOliveGreen;
            btsalir.Location = new Point(0, 719);
            btsalir.Margin = new Padding(4);
            btsalir.Name = "btsalir";
            btsalir.Padding = new Padding(11, 0, 0, 0);
            btsalir.Size = new Size(291, 34);
            btsalir.TabIndex = 7;
            btsalir.Text = "Cerrar";
            btsalir.TextAlign = ContentAlignment.MiddleRight;
            btsalir.UseVisualStyleBackColor = true;
            btsalir.Click += btsalir_Click;
            btsalir.MouseEnter += btmostprod_MouseEnter;
            // 
            // btregemp
            // 
            btregemp.Dock = DockStyle.Top;
            btregemp.FlatAppearance.BorderSize = 0;
            btregemp.FlatStyle = FlatStyle.Flat;
            btregemp.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            btregemp.ForeColor = Color.DarkOliveGreen;
            btregemp.Location = new Point(0, 457);
            btregemp.Margin = new Padding(4);
            btregemp.Name = "btregemp";
            btregemp.Padding = new Padding(11, 0, 0, 0);
            btregemp.Size = new Size(291, 46);
            btregemp.TabIndex = 6;
            btregemp.Text = "Registrar empleado";
            btregemp.TextAlign = ContentAlignment.MiddleLeft;
            btregemp.UseVisualStyleBackColor = true;
            btregemp.Click += btregemp_Click;
            btregemp.MouseEnter += btmostprod_MouseEnter;
            // 
            // btregprod
            // 
            btregprod.Dock = DockStyle.Top;
            btregprod.FlatAppearance.BorderSize = 0;
            btregprod.FlatStyle = FlatStyle.Flat;
            btregprod.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            btregprod.ForeColor = Color.DarkOliveGreen;
            btregprod.Location = new Point(0, 411);
            btregprod.Margin = new Padding(4);
            btregprod.Name = "btregprod";
            btregprod.Padding = new Padding(11, 0, 0, 0);
            btregprod.Size = new Size(291, 46);
            btregprod.TabIndex = 5;
            btregprod.Text = "Registrar producto";
            btregprod.TextAlign = ContentAlignment.MiddleLeft;
            btregprod.UseVisualStyleBackColor = true;
            btregprod.Click += btregprod_Click;
            btregprod.MouseEnter += btmostprod_MouseEnter;
            // 
            // panelsubmenumostvent
            // 
            panelsubmenumostvent.BackColor = Color.FromArgb(224, 224, 224);
            panelsubmenumostvent.Controls.Add(btmisvent);
            panelsubmenumostvent.Controls.Add(btmostventot);
            panelsubmenumostvent.Controls.Add(btmostventemp);
            panelsubmenumostvent.Dock = DockStyle.Top;
            panelsubmenumostvent.Location = new Point(0, 281);
            panelsubmenumostvent.Margin = new Padding(4);
            panelsubmenumostvent.Name = "panelsubmenumostvent";
            panelsubmenumostvent.Size = new Size(291, 130);
            panelsubmenumostvent.TabIndex = 4;
            // 
            // btmisvent
            // 
            btmisvent.Dock = DockStyle.Top;
            btmisvent.FlatAppearance.BorderSize = 0;
            btmisvent.FlatStyle = FlatStyle.Flat;
            btmisvent.Font = new Font("Microsoft Sans Serif", 9.749999F, FontStyle.Regular, GraphicsUnit.Point);
            btmisvent.ForeColor = Color.DarkOliveGreen;
            btmisvent.Location = new Point(0, 80);
            btmisvent.Margin = new Padding(4);
            btmisvent.Name = "btmisvent";
            btmisvent.Padding = new Padding(41, 0, 0, 0);
            btmisvent.Size = new Size(291, 40);
            btmisvent.TabIndex = 2;
            btmisvent.Text = "Mis ventas";
            btmisvent.TextAlign = ContentAlignment.MiddleLeft;
            btmisvent.UseVisualStyleBackColor = true;
            btmisvent.Click += btmisvent_Click;
            // 
            // btmostventot
            // 
            btmostventot.Dock = DockStyle.Top;
            btmostventot.FlatAppearance.BorderSize = 0;
            btmostventot.FlatStyle = FlatStyle.Flat;
            btmostventot.Font = new Font("Microsoft Sans Serif", 9.749999F, FontStyle.Regular, GraphicsUnit.Point);
            btmostventot.ForeColor = Color.DarkOliveGreen;
            btmostventot.Location = new Point(0, 40);
            btmostventot.Margin = new Padding(4);
            btmostventot.Name = "btmostventot";
            btmostventot.Padding = new Padding(41, 0, 0, 0);
            btmostventot.Size = new Size(291, 40);
            btmostventot.TabIndex = 1;
            btmostventot.Text = "Ventas por día";
            btmostventot.TextAlign = ContentAlignment.MiddleLeft;
            btmostventot.UseVisualStyleBackColor = true;
            btmostventot.Click += btmostventot_Click;
            // 
            // btmostventemp
            // 
            btmostventemp.Dock = DockStyle.Top;
            btmostventemp.FlatAppearance.BorderSize = 0;
            btmostventemp.FlatStyle = FlatStyle.Flat;
            btmostventemp.Font = new Font("Microsoft Sans Serif", 9.749999F, FontStyle.Regular, GraphicsUnit.Point);
            btmostventemp.ForeColor = Color.DarkOliveGreen;
            btmostventemp.Location = new Point(0, 0);
            btmostventemp.Margin = new Padding(4);
            btmostventemp.Name = "btmostventemp";
            btmostventemp.Padding = new Padding(41, 0, 0, 0);
            btmostventemp.Size = new Size(291, 40);
            btmostventemp.TabIndex = 0;
            btmostventemp.Text = "Ventas por empleado";
            btmostventemp.TextAlign = ContentAlignment.MiddleLeft;
            btmostventemp.UseVisualStyleBackColor = true;
            btmostventemp.Click += btmostventemp_Click;
            // 
            // btmostvent
            // 
            btmostvent.Dock = DockStyle.Top;
            btmostvent.FlatAppearance.BorderSize = 0;
            btmostvent.FlatStyle = FlatStyle.Flat;
            btmostvent.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            btmostvent.ForeColor = Color.DarkOliveGreen;
            btmostvent.Location = new Point(0, 235);
            btmostvent.Margin = new Padding(4);
            btmostvent.Name = "btmostvent";
            btmostvent.Padding = new Padding(11, 0, 0, 0);
            btmostvent.Size = new Size(291, 46);
            btmostvent.TabIndex = 3;
            btmostvent.Text = "Mostrar ventas";
            btmostvent.TextAlign = ContentAlignment.MiddleLeft;
            btmostvent.UseVisualStyleBackColor = true;
            btmostvent.MouseEnter += btmostvent_MouseEnter;
            // 
            // btmostemp
            // 
            btmostemp.Dock = DockStyle.Top;
            btmostemp.FlatAppearance.BorderSize = 0;
            btmostemp.FlatStyle = FlatStyle.Flat;
            btmostemp.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            btmostemp.ForeColor = Color.DarkOliveGreen;
            btmostemp.Location = new Point(0, 189);
            btmostemp.Margin = new Padding(4);
            btmostemp.Name = "btmostemp";
            btmostemp.Padding = new Padding(11, 0, 0, 0);
            btmostemp.Size = new Size(291, 46);
            btmostemp.TabIndex = 2;
            btmostemp.Text = "Mostrar empleados";
            btmostemp.TextAlign = ContentAlignment.MiddleLeft;
            btmostemp.UseVisualStyleBackColor = true;
            btmostemp.Click += btmostemp_Click;
            btmostemp.MouseEnter += btmostprod_MouseEnter;
            // 
            // btmostprod
            // 
            btmostprod.Dock = DockStyle.Top;
            btmostprod.FlatAppearance.BorderSize = 0;
            btmostprod.FlatStyle = FlatStyle.Flat;
            btmostprod.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            btmostprod.ForeColor = Color.DarkOliveGreen;
            btmostprod.Location = new Point(0, 143);
            btmostprod.Margin = new Padding(4);
            btmostprod.Name = "btmostprod";
            btmostprod.Padding = new Padding(11, 0, 0, 0);
            btmostprod.Size = new Size(291, 46);
            btmostprod.TabIndex = 1;
            btmostprod.Text = "Mostrar productos";
            btmostprod.TextAlign = ContentAlignment.MiddleLeft;
            btmostprod.UseVisualStyleBackColor = true;
            btmostprod.Click += btmostprod_Click;
            btmostprod.MouseEnter += btmostprod_MouseEnter;
            // 
            // panellogo
            // 
            panellogo.Controls.Add(pictureBox1);
            panellogo.Dock = DockStyle.Top;
            panellogo.Location = new Point(0, 0);
            panellogo.Margin = new Padding(4);
            panellogo.Name = "panellogo";
            panellogo.Size = new Size(291, 143);
            panellogo.TabIndex = 0;
            // 
            // pictureBox1
            // 
            pictureBox1.Dock = DockStyle.Left;
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Margin = new Padding(4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(291, 143);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            pictureBox1.MouseEnter += btmostprod_MouseEnter;
            // 
            // contextMenuStrip1
            // 
            contextMenuStrip1.Name = "contextMenuStrip1";
            contextMenuStrip1.Size = new Size(61, 4);
            // 
            // MenuPrincipal
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1199, 753);
            Controls.Add(panelformularioactivo);
            Controls.Add(panelmenulateral);
            Margin = new Padding(4);
            Name = "MenuPrincipal";
            Text = "MenuPrincipal";
            panelformularioactivo.ResumeLayout(false);
            panelmenulateral.ResumeLayout(false);
            panelsubmenumostvent.ResumeLayout(false);
            panellogo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panelformularioactivo;
        private Label lblogopredmainadm;
        private Panel panelmenulateral;
        private Button btregvent;
        private Button btayuda;
        private Button btmiperfil;
        private Button button1;
        private Button btsalir;
        private Button btregemp;
        private Button btregprod;
        private Panel panelsubmenumostvent;
        private Button btmisvent;
        private Button btmostventot;
        private Button btmostventemp;
        private Button btmostvent;
        private Button btmostemp;
        private Button btmostprod;
        private Panel panellogo;
        private PictureBox pictureBox1;
        private Button button2;
        private ContextMenuStrip contextMenuStrip1;
    }
}