﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FACTURACION
{
    public class Nodo
    {
        public string Nombre { get; set; }
        public List<Nodo> Hijos { get; set; } = new List<Nodo>();
        public List<Productos> Productos { get; set; } = new List<Productos>();

        private const int Radio = 50;
        private const int DistanciaH = 80;
        private const int DistanciaV = 100;
        public int CoordenadaX { get; set; }
        public int CoordenadaY { get; set; }

        public Nodo(string nombre)
        {
            Nombre = nombre;
        }
        public Nodo ObtenerOAgregarNodoHijo(string nombre)
        {
            var nodo = Hijos.FirstOrDefault(h => h.Nombre == nombre);
            if (nodo == null)
            {
                nodo = new Nodo(nombre);
                Hijos.Add(nodo);
            }
            return nodo;
        }
        public void DibujarNodo(Graphics grafo, Font fuente, Brush Relleno, Brush RellenoFuente, Pen Lapiz, Brush encuentro)
        {

            Rectangle rect = new Rectangle((int)(CoordenadaX - Radio / 2), (int)(CoordenadaY - Radio / 2), Radio, Radio);
            grafo.FillEllipse(encuentro, rect);
            grafo.FillEllipse(Relleno, rect);
            grafo.DrawEllipse(Lapiz, rect);


            StringFormat formato = new StringFormat();
            formato.Alignment = StringAlignment.Center;
            formato.LineAlignment = StringAlignment.Center;
            grafo.DrawString(Nombre, fuente, RellenoFuente, CoordenadaX, CoordenadaY, formato);


            int yProducto = CoordenadaY + 30;
            foreach (var producto in Productos)
            {
                grafo.DrawString(producto.Nombre, fuente, RellenoFuente, CoordenadaX, yProducto, formato);
                yProducto += 15;
            }


            if (Hijos != null)
            {
                foreach (var hijo in Hijos)
                {
                    hijo.DibujarNodo(grafo, fuente, Relleno, RellenoFuente, Lapiz, encuentro);
                }
            }
        }


        public void Colorear(Graphics grafo, Font fuente, Brush Relleno, Brush RellenoFuente, Pen Lapiz)
        {
            Rectangle rect = new Rectangle((int)(CoordenadaX - Radio / 2), (int)(CoordenadaY - Radio / 2), Radio, Radio);
            grafo.FillEllipse(Relleno, rect);
            grafo.DrawEllipse(Lapiz, rect);

            StringFormat formato = new StringFormat
            {
                Alignment = StringAlignment.Center,
                LineAlignment = StringAlignment.Center
            };

            grafo.DrawString(Nombre, fuente, RellenoFuente, CoordenadaX, CoordenadaY, formato);
        }

        public int MaxNodosEnNivel(int nivel)
        {
            if (nivel == 0) return 1;
            int count = 0;
            foreach (var hijo in Hijos)
            {
                count += hijo.MaxNodosEnNivel(nivel - 1);
            }
            return count;
        }

        public void PosicionNodo(ref int xmin, int ymin, int anchoVentana, int nivel)
        {
            int maxNodos = MaxNodosEnNivel(nivel);
            int distanciaH = anchoVentana / (maxNodos + 1);

            CoordenadaY = (int)(ymin + Radio);

            if (Hijos != null && Hijos.Count > 0)
            {

                Hijos[0].PosicionNodo(ref xmin, ymin + Radio + DistanciaV, anchoVentana, nivel + 1);
            }


            if (Hijos != null && Hijos.Count == 2)
            {
                xmin += distanciaH;
            }


            if (Hijos != null && Hijos.Count > 1)
            {
                for (int i = 1; i < Hijos.Count; i++)
                {
                    Hijos[i].PosicionNodo(ref xmin, ymin + Radio + DistanciaV, anchoVentana, nivel + 1);
                    xmin += distanciaH;
                }
            }

            if (Hijos != null && Hijos.Count > 0)
            {

                CoordenadaX = (int)(Hijos.Average(h => h.CoordenadaX));
            }
            else
            {

                CoordenadaX = (int)(xmin + distanciaH);
                xmin += distanciaH;
            }
        }




        public void DibujarRamas(Graphics grafo, Pen Lapiz)
        {
            foreach (var hijo in Hijos)
            {
                grafo.DrawLine(Lapiz, CoordenadaX, CoordenadaY, hijo.CoordenadaX,
                hijo.CoordenadaY);
                hijo.DibujarRamas(grafo, Lapiz);
            }
        }
    }
}
