﻿namespace FACTURACION
{
    partial class regEmpleado
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label6 = new Label();
            cmbcargo = new ComboBox();
            btnregistrar = new Button();
            btnborrar = new Button();
            btncerrar = new Button();
            txtpassword = new TextBox();
            txtusuario = new TextBox();
            txtdireccion = new TextBox();
            txttelefono = new TextBox();
            txtapellido = new TextBox();
            txtnombre = new TextBox();
            label8 = new Label();
            label7 = new Label();
            label1 = new Label();
            label5 = new Label();
            label2 = new Label();
            label4 = new Label();
            label3 = new Label();
            label9 = new Label();
            SuspendLayout();
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI Black", 22.2F, FontStyle.Bold, GraphicsUnit.Point);
            label6.ForeColor = SystemColors.ButtonHighlight;
            label6.Location = new Point(172, -46);
            label6.Name = "label6";
            label6.Size = new Size(330, 41);
            label6.TabIndex = 18;
            label6.Text = "Registro de producto";
            // 
            // cmbcargo
            // 
            cmbcargo.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold, GraphicsUnit.Point);
            cmbcargo.FormattingEnabled = true;
            cmbcargo.Location = new Point(172, 517);
            cmbcargo.Name = "cmbcargo";
            cmbcargo.Size = new Size(434, 37);
            cmbcargo.TabIndex = 41;
            // 
            // btnregistrar
            // 
            btnregistrar.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            btnregistrar.Location = new Point(716, 639);
            btnregistrar.Name = "btnregistrar";
            btnregistrar.Size = new Size(139, 37);
            btnregistrar.TabIndex = 40;
            btnregistrar.Text = "Registrar";
            btnregistrar.UseVisualStyleBackColor = true;
            btnregistrar.Click += btnregistrar_Click;
            // 
            // btnborrar
            // 
            btnborrar.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            btnborrar.Location = new Point(576, 639);
            btnborrar.Name = "btnborrar";
            btnborrar.Size = new Size(109, 37);
            btnborrar.TabIndex = 39;
            btnborrar.Text = "Borrar";
            btnborrar.UseVisualStyleBackColor = true;
            btnborrar.Click += btnborrar_Click;
            // 
            // btncerrar
            // 
            btncerrar.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            btncerrar.Location = new Point(52, 639);
            btncerrar.Name = "btncerrar";
            btncerrar.Size = new Size(109, 37);
            btncerrar.TabIndex = 38;
            btncerrar.Text = "Cerrar";
            btncerrar.UseVisualStyleBackColor = true;
            btncerrar.Click += btncerrar_Click;
            // 
            // txtpassword
            // 
            txtpassword.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold, GraphicsUnit.Point);
            txtpassword.Location = new Point(674, 276);
            txtpassword.Name = "txtpassword";
            txtpassword.Size = new Size(181, 35);
            txtpassword.TabIndex = 37;
            txtpassword.UseSystemPasswordChar = true;
            // 
            // txtusuario
            // 
            txtusuario.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold, GraphicsUnit.Point);
            txtusuario.Location = new Point(674, 183);
            txtusuario.Name = "txtusuario";
            txtusuario.Size = new Size(181, 35);
            txtusuario.TabIndex = 36;
            // 
            // txtdireccion
            // 
            txtdireccion.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold, GraphicsUnit.Point);
            txtdireccion.Location = new Point(172, 414);
            txtdireccion.Name = "txtdireccion";
            txtdireccion.Size = new Size(434, 35);
            txtdireccion.TabIndex = 35;
            // 
            // txttelefono
            // 
            txttelefono.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold, GraphicsUnit.Point);
            txttelefono.Location = new Point(172, 323);
            txttelefono.Name = "txttelefono";
            txttelefono.Size = new Size(434, 35);
            txttelefono.TabIndex = 34;
            // 
            // txtapellido
            // 
            txtapellido.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold, GraphicsUnit.Point);
            txtapellido.Location = new Point(172, 230);
            txtapellido.Name = "txtapellido";
            txtapellido.Size = new Size(434, 35);
            txtapellido.TabIndex = 33;
            // 
            // txtnombre
            // 
            txtnombre.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold, GraphicsUnit.Point);
            txtnombre.Location = new Point(172, 137);
            txtnombre.Name = "txtnombre";
            txtnombre.Size = new Size(434, 35);
            txtnombre.TabIndex = 32;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            label8.ForeColor = Color.White;
            label8.Location = new Point(697, 236);
            label8.Name = "label8";
            label8.Size = new Size(129, 25);
            label8.TabIndex = 31;
            label8.Text = "Contraseña:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            label7.ForeColor = Color.White;
            label7.Location = new Point(716, 143);
            label7.Name = "label7";
            label7.Size = new Size(92, 25);
            label7.TabIndex = 30;
            label7.Text = "Usuario:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            label1.ForeColor = Color.White;
            label1.Location = new Point(46, 523);
            label1.Name = "label1";
            label1.Size = new Size(76, 25);
            label1.TabIndex = 29;
            label1.Text = "Cargo:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            label5.ForeColor = Color.White;
            label5.Location = new Point(46, 424);
            label5.Name = "label5";
            label5.Size = new Size(108, 25);
            label5.TabIndex = 28;
            label5.Text = "Dirección:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Microsoft Sans Serif", 27.75F, FontStyle.Bold, GraphicsUnit.Point);
            label2.ForeColor = Color.White;
            label2.Location = new Point(46, 43);
            label2.Name = "label2";
            label2.Size = new Size(350, 42);
            label2.TabIndex = 25;
            label2.Text = "Perfil de Empleado";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            label4.ForeColor = Color.White;
            label4.Location = new Point(46, 236);
            label4.Name = "label4";
            label4.Size = new Size(106, 25);
            label4.TabIndex = 27;
            label4.Text = "Apellidos:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            label3.ForeColor = Color.White;
            label3.Location = new Point(46, 329);
            label3.Name = "label3";
            label3.Size = new Size(102, 25);
            label3.TabIndex = 26;
            label3.Text = "Teléfono:";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            label9.ForeColor = Color.White;
            label9.Location = new Point(46, 143);
            label9.Name = "label9";
            label9.Size = new Size(104, 25);
            label9.TabIndex = 24;
            label9.Text = "Nombres:";
            // 
            // regEmpleado
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.DarkOliveGreen;
            ClientSize = new Size(900, 718);
            Controls.Add(cmbcargo);
            Controls.Add(btnregistrar);
            Controls.Add(btnborrar);
            Controls.Add(btncerrar);
            Controls.Add(txtpassword);
            Controls.Add(txtusuario);
            Controls.Add(txtdireccion);
            Controls.Add(txttelefono);
            Controls.Add(txtapellido);
            Controls.Add(txtnombre);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label1);
            Controls.Add(label5);
            Controls.Add(label2);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label9);
            Controls.Add(label6);
            Margin = new Padding(3, 2, 3, 2);
            Name = "regEmpleado";
            Text = "regEmpleado";
            Load += regEmpleado_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Label label6;
        private TextBox txtApellido;
        private TextBox txtNombre;
        private Label label5;
        private Label label2;
        private TextBox txtUsuario;
        private Label label1;
        private TextBox txtContrasena;
        private Label label3;
        private Label label4;
        private ComboBox cmbcargo;
        private Button btnregistrar;
        private Button btnborrar;
        private Button btncerrar;
        private TextBox txtpassword;
        private TextBox txtusuario;
        private TextBox txtdireccion;
        private TextBox txttelefono;
        private TextBox txtapellido;
        private TextBox txtnombre;
        private Label label8;
        private Label label7;
        private Label label9;
    }
}