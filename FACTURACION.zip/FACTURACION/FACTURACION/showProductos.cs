﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FACTURACION
{
    public partial class showProductos : Form
    {
        public static int codigobusqueda = 0;
        private ConexionBD conexionBD = new ConexionBD();

        public showProductos()
        {
            InitializeComponent();
            txtcodigo.Enabled = true;
            btnir.Enabled = true;
        }

        private void showProductos_Load(object sender, EventArgs e)
        {
            CargarProductos();
        }

        private void CargarProductos()
        {
            using (var conexion = conexionBD.ObtenerConexion())
            {
                string query = "SELECT idproducto, nombre, categoria, descripcion, cantidad_inventario, precio FROM Producto;";
                using (var comando = new MySqlCommand(query, conexion))
                {
                    DataTable dt = new DataTable();
                    MySqlDataAdapter adaptador = new MySqlDataAdapter(comando);
                    adaptador.Fill(dt);

                    dgvProductos.DataSource = dt;
                }
            }
        }


        private void btnir_Click_1(object sender, EventArgs e)
        {
            if (txtcodigo.Text != "")
            {
                using (var conexion = conexionBD.ObtenerConexion())
                {
                    string query = "SELECT idproducto FROM producto WHERE idproducto = @idproducto";
                    using (var comando = new MySqlCommand(query, conexion))
                    {
                        comando.Parameters.AddWithValue("@idproducto", int.Parse(txtcodigo.Text));
                        using (var rdr = comando.ExecuteReader())
                        {
                            while (rdr.Read())
                            {
                                if (rdr.IsDBNull(0))
                                {

                                }
                                else
                                {
                                    codigobusqueda = rdr.GetInt16(0);
                                    modempleado empleado = new modempleado();
                                    empleado.ShowDialog();
                                }
                            }
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Por favor ingrese un codigo de producto");
            }
        }
    }

}
