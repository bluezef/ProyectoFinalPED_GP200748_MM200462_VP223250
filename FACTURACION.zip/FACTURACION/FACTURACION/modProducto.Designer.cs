﻿namespace FACTURACION
{
    partial class modProducto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label5 = new Label();
            txtNombre = new TextBox();
            txtCantidad = new TextBox();
            btnModificar = new Button();
            btnCerrar = new Button();
            cmbcategoria = new ComboBox();
            txtPrecio = new TextBox();
            label7 = new Label();
            label4 = new Label();
            txtdescripcion = new TextBox();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 27F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.White;
            label1.Location = new Point(13, 10);
            label1.Name = "label1";
            label1.Size = new Size(317, 40);
            label1.TabIndex = 0;
            label1.Text = "Perfil de producto";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            label2.ForeColor = Color.White;
            label2.Location = new Point(237, 81);
            label2.Name = "label2";
            label2.Size = new Size(93, 25);
            label2.TabIndex = 1;
            label2.Text = "Nombre:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            label3.ForeColor = Color.White;
            label3.Location = new Point(190, 129);
            label3.Name = "label3";
            label3.Size = new Size(140, 25);
            label3.TabIndex = 2;
            label3.Text = "Clasificación:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            label5.ForeColor = Color.White;
            label5.Location = new Point(96, 224);
            label5.Name = "label5";
            label5.Size = new Size(234, 25);
            label5.TabIndex = 4;
            label5.Text = "Cantidad en inventario:";
            // 
            // txtNombre
            // 
            txtNombre.Location = new Point(336, 86);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new Size(304, 23);
            txtNombre.TabIndex = 9;
            // 
            // txtCantidad
            // 
            txtCantidad.Location = new Point(336, 222);
            txtCantidad.Name = "txtCantidad";
            txtCantidad.Size = new Size(304, 23);
            txtCantidad.TabIndex = 15;
            // 
            // btnModificar
            // 
            btnModificar.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            btnModificar.Location = new Point(585, 416);
            btnModificar.Name = "btnModificar";
            btnModificar.Size = new Size(112, 31);
            btnModificar.TabIndex = 16;
            btnModificar.Text = "Modificar";
            btnModificar.UseVisualStyleBackColor = true;
            btnModificar.Click += btnModificar_Click;
            // 
            // btnCerrar
            // 
            btnCerrar.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            btnCerrar.Location = new Point(13, 416);
            btnCerrar.Name = "btnCerrar";
            btnCerrar.Size = new Size(82, 31);
            btnCerrar.TabIndex = 17;
            btnCerrar.Text = "Cerrar";
            btnCerrar.UseVisualStyleBackColor = true;
            btnCerrar.Click += btnCerrar_Click;
            // 
            // cmbcategoria
            // 
            cmbcategoria.FormattingEnabled = true;
            cmbcategoria.Location = new Point(336, 131);
            cmbcategoria.Name = "cmbcategoria";
            cmbcategoria.Size = new Size(304, 23);
            cmbcategoria.TabIndex = 19;
            // 
            // txtPrecio
            // 
            txtPrecio.Location = new Point(336, 178);
            txtPrecio.Name = "txtPrecio";
            txtPrecio.Size = new Size(304, 23);
            txtPrecio.TabIndex = 11;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            label7.ForeColor = Color.White;
            label7.Location = new Point(251, 176);
            label7.Name = "label7";
            label7.Size = new Size(79, 25);
            label7.TabIndex = 6;
            label7.Text = "Precio:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            label4.ForeColor = Color.White;
            label4.Location = new Point(199, 268);
            label4.Name = "label4";
            label4.Size = new Size(131, 25);
            label4.TabIndex = 20;
            label4.Text = "Descripcion:";
            // 
            // txtdescripcion
            // 
            txtdescripcion.Location = new Point(336, 268);
            txtdescripcion.Name = "txtdescripcion";
            txtdescripcion.Size = new Size(304, 23);
            txtdescripcion.TabIndex = 21;
            // 
            // modProducto
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.DarkOliveGreen;
            ClientSize = new Size(800, 459);
            Controls.Add(txtdescripcion);
            Controls.Add(label4);
            Controls.Add(cmbcategoria);
            Controls.Add(btnCerrar);
            Controls.Add(btnModificar);
            Controls.Add(txtCantidad);
            Controls.Add(txtPrecio);
            Controls.Add(txtNombre);
            Controls.Add(label7);
            Controls.Add(label5);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "modProducto";
            Text = "modProducto";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label5;
        private TextBox txtNombre;
        private TextBox txtCantidad;
        private Button btnModificar;
        private Button btnCerrar;
        private Button btnBorrar;
        private ComboBox cmbcategoria;
        private TextBox txtPrecio;
        private Label label7;
        private Label label4;
        private TextBox txtdescripcion;
    }
}