﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FACTURACION
{
    internal class Producto
    {

        public int ID { get; set; }
        public string Nombre { get; set; }
        public decimal Precio { get; set; }
        public int Cantidad { get; set; } 

        public Producto()
        {
        }

        public Producto(int id, string nombre, decimal precio, int cantidad)
        {
            ID = id;
            Nombre = nombre;
            Precio = precio;
            Cantidad = cantidad;
        }
    }
}
