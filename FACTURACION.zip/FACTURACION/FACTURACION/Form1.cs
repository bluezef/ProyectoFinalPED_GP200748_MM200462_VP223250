﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace FACTURACION
{
    public partial class Form1 : Form
    {
        MenuPrincipal administrador;

        Arbol arbol;
        public Form1()
        {
            InitializeComponent();
            this.MinimumSize = new System.Drawing.Size(917, 661);
        }
        
        private async void Form1_Load_1(object sender, EventArgs e)
        {
            Task esperachica = new Task(esperita), esperabien = new Task(espera);
            esperachica.Start();
            await esperachica; this.Hide();
            Form cargabienvenida = new PantallaBienvenida();
            cargabienvenida.Show();
            cargabienvenida.BringToFront();
            esperabien.Start();
            await esperabien; cargabienvenida.Close();
            cargabienvenida.Close();
            this.Show();
            
           
        }

        //metodo que se encarga de que pasen 6 segundos
        public void espera()
        {
            Thread.Sleep(6000);
        }
        //metodo que se encarga de que pasen 5 segundos
        public void esperausuario()
        {
            Thread.Sleep(5000);
        }
        //metodo que se encarga de que pasen 4 segundos
        public void esperacargauser()
        {
            Thread.Sleep(4000);
        }
        //metodo que se encarga de que pasen 0 segundos
        public void esperita()
        {
            Thread.Sleep(0);
        }


        private bool validar_credenciales(string usuario, string contrasena)
        {
            bool credencialesValidas = false;

            using (var conexionBD = new ConexionBD())
            {
                var conexion = conexionBD.ObtenerConexion();

                string query = "SELECT COUNT(1) FROM usuario WHERE usuario = @nombreUsuario AND pass = @contrasena";

                using (var comando = new MySqlCommand(query, conexion))
                {
                    comando.Parameters.AddWithValue("@nombreUsuario", usuario);
                    comando.Parameters.AddWithValue("@contrasena", contrasena);

                    int resultado = Convert.ToInt32(comando.ExecuteScalar());

                    if (resultado == 1)
                    {   
                        credencialesValidas = true;
                    }
                }

                conexionBD.CerrarConexion();
            }
            if (credencialesValidas)
            {
                InformacionUsuario.EstablecerUsuarioActual(usuario);
            }

            return credencialesValidas;
        }


        private void bton_acceder_Click(object sender, EventArgs e)
        {
            bool confirmacion;
            confirmacion = validar_credenciales(textBox_usuario.Text, textBox_clave.Text);
            if (confirmacion)
            {
                administrador = new MenuPrincipal();
                this.Hide();

                administrador.Show();
                textBox_usuario.Clear();
                textBox_clave.Clear();
                
            }
            else
                MessageBox.Show("Por favor, ingrese un nombre de usuario y una contraseña válidos", "Inválido", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void textBox_usuario_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                bool confirmacion;
                confirmacion = validar_credenciales(textBox_usuario.Text, textBox_clave.Text);
                if (confirmacion)
                {
                    administrador = new MenuPrincipal();
                    this.Hide();
                    administrador.Show();
                    textBox_usuario.Clear();
                    textBox_clave.Clear();
                }
                else
                    MessageBox.Show("Por favor, ingrese un nombre de usuario y una contraseña válidos", "Inválido", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void textBox_clave_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter))
            {
                bool confirmacion;
                confirmacion = validar_credenciales(textBox_usuario.Text, textBox_clave.Text);
                if (confirmacion)
                {
                    administrador = new MenuPrincipal();
                    this.Hide();
                    administrador.Show();
                    textBox_usuario.Clear();
                    textBox_clave.Clear();
                }
                else
                    MessageBox.Show("Por favor, ingrese un nombre de usuario y una contraseña válidos", "Inválido", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                textBox_clave.UseSystemPasswordChar = false;
            }
            else
            {
                textBox_clave.UseSystemPasswordChar = true;
            }
        }

        private void textBox_clave_TextChanged(object sender, EventArgs e)
        {
            if (textBox_clave.Text.Length >= 6) failTamaño.SetError(textBox_clave, string.Empty);
            else failTamaño.SetError(textBox_clave, "Debe ingresar al menos 6 caracteres");
        }

        private void bton_cancelar_Click(object sender, EventArgs e)
        {
            textBox_clave.Clear();
            textBox_usuario.Clear();
        }
    }
}
