﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FACTURACION
{
    public partial class miPerfil : Form
    {
        private ConexionBD conexionBD = new ConexionBD();

        public miPerfil()
        {
            InitializeComponent();
        }

        private void miPerfil_Load(object sender, EventArgs e)
        {
            CargarInformacionUsuario();
        }

        private void CargarInformacionUsuario()
        {
            string query = "SELECT nombres, apellidos, usuario FROM usuario WHERE usuario = @nombre_usuario";

            using (var conexion = conexionBD.ObtenerConexion())
            {
                using (var comando = new MySqlCommand(query, conexion))
                {
                    comando.Parameters.AddWithValue("@nombre_usuario", InformacionUsuario.NombreUsuario);
                    using (var reader = comando.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            lblNombre.Text = "Nombres :"+reader.GetString(0);
                            lblApellido.Text = "Apellidos :" + reader.GetString(1);
                            lblUsuario.Text = "Usuario :" + reader.GetString(2);
                        }
                        else
                        {
                            MessageBox.Show("No se encontró el usuario.");
                        }
                    }
                }
            }
        }
    }

}
