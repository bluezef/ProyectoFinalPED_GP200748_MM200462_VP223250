﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace FACTURACION
{
    public class Arbol
    {
        public Nodo Raiz { get; private set; }
        private ConexionBD conexionBD = new ConexionBD();

        public Arbol()
        {
            Raiz = new Nodo("Categorías de Productos");

            using (var conexion = conexionBD.ObtenerConexion())
            {
                string query = "SELECT nombre FROM categoria";
                using (var comando = new MySqlCommand(query, conexion))
                {
                    using (var rdr = comando.ExecuteReader())
                    {
                        while (rdr.Read())
                        {
                            for (int i = 0; i < rdr.FieldCount; i++)
                            {
                                Raiz.ObtenerOAgregarNodoHijo(rdr.GetString(i));
                            }
                        }
                    }
                }
            }


        }

        public void Agregar(Productos productonodo)
        {
            Nodo nodoCategoria = Raiz.Hijos.First(n => n.Nombre == productonodo.Categoria);

            nodoCategoria.Productos.Add(productonodo);
        }

        public string Buscar(string nombreProducto)
        {
            foreach (var categoria in Raiz.Hijos)
            {
                foreach (var producto in categoria.Productos)
                {
                    if (producto.Nombre == nombreProducto)
                    {
                        return categoria.Nombre;
                    }
                }
            }
            return null;
        }

        public void DibujarArbol(Graphics grafo, Font fuente, Brush Relleno, Brush RellenoFuente, Pen Lapiz, Brush encuentro)
        {
            int x = 400;
            int y = 75;
            if (Raiz == null) return;
            Raiz.PosicionNodo(ref x, y, 100, 0);
            Raiz.DibujarRamas(grafo, Lapiz);
            Raiz.DibujarNodo(grafo, fuente, Relleno, RellenoFuente, Lapiz, encuentro);
        }

        public void colorear(Graphics grafo, Font fuente, Brush Relleno, Brush RellenoFuente, Pen Lapiz, Nodo raiz)
        {
            Brush entorno = Brushes.White;
            if (raiz != null)
            {
                raiz.Colorear(grafo, fuente, entorno, RellenoFuente, Lapiz);
                Thread.Sleep(1000);
                raiz.Colorear(grafo, fuente, Relleno, RellenoFuente, Lapiz);
                foreach (var hijo in raiz.Hijos)
                {
                    colorear(grafo, fuente, Relleno, RellenoFuente, Lapiz, hijo);
                }
            }
        }
    }
}
