﻿namespace FACTURACION
{
    partial class regVenta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label6 = new Label();
            label5 = new Label();
            txtCliente = new TextBox();
            label1 = new Label();
            dtpFecha = new DateTimePicker();
            label2 = new Label();
            cmbProducto = new ComboBox();
            label3 = new Label();
            txtPrecio = new TextBox();
            txtCantidad = new TextBox();
            label4 = new Label();
            btnAdd = new Button();
            dgvProductos = new DataGridView();
            ID = new DataGridViewTextBoxColumn();
            Producto = new DataGridViewTextBoxColumn();
            Cantidad = new DataGridViewTextBoxColumn();
            Precio = new DataGridViewTextBoxColumn();
            Subtotal = new DataGridViewTextBoxColumn();
            lblTotalGeneral = new Label();
            button1 = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvProductos).BeginInit();
            SuspendLayout();
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI Black", 22.2F, FontStyle.Bold, GraphicsUnit.Point);
            label6.ForeColor = SystemColors.ButtonHighlight;
            label6.Location = new Point(301, 69);
            label6.Name = "label6";
            label6.Size = new Size(346, 50);
            label6.TabIndex = 13;
            label6.Text = "Registro de Venta";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            label5.ForeColor = SystemColors.ButtonHighlight;
            label5.Location = new Point(61, 140);
            label5.Name = "label5";
            label5.Size = new Size(89, 31);
            label5.TabIndex = 14;
            label5.Text = "Cliente";
            // 
            // txtCliente
            // 
            txtCliente.Location = new Point(183, 144);
            txtCliente.Name = "txtCliente";
            txtCliente.Size = new Size(151, 27);
            txtCliente.TabIndex = 15;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = SystemColors.ButtonHighlight;
            label1.Location = new Point(420, 140);
            label1.Name = "label1";
            label1.Size = new Size(75, 31);
            label1.TabIndex = 16;
            label1.Text = "Fecha";
            // 
            // dtpFecha
            // 
            dtpFecha.Location = new Point(501, 144);
            dtpFecha.Name = "dtpFecha";
            dtpFecha.Size = new Size(290, 27);
            dtpFecha.TabIndex = 17;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            label2.ForeColor = SystemColors.ButtonHighlight;
            label2.Location = new Point(61, 219);
            label2.Name = "label2";
            label2.Size = new Size(113, 31);
            label2.TabIndex = 18;
            label2.Text = "Producto";
            // 
            // cmbProducto
            // 
            cmbProducto.FormattingEnabled = true;
            cmbProducto.Items.AddRange(new object[] { "Ropa", "Comida", "Bebidas", "Electrodomestico", "Tecnologia" });
            cmbProducto.Location = new Point(183, 225);
            cmbProducto.Name = "cmbProducto";
            cmbProducto.Size = new Size(151, 28);
            cmbProducto.TabIndex = 19;
            cmbProducto.SelectedIndexChanged += cmbProducto_SelectedIndexChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            label3.ForeColor = SystemColors.ButtonHighlight;
            label3.Location = new Point(420, 222);
            label3.Name = "label3";
            label3.Size = new Size(81, 31);
            label3.TabIndex = 20;
            label3.Text = "Precio";
            // 
            // txtPrecio
            // 
            txtPrecio.Location = new Point(507, 225);
            txtPrecio.Name = "txtPrecio";
            txtPrecio.Size = new Size(151, 27);
            txtPrecio.TabIndex = 21;
            // 
            // txtCantidad
            // 
            txtCantidad.Location = new Point(816, 222);
            txtCantidad.Name = "txtCantidad";
            txtCantidad.Size = new Size(151, 27);
            txtCantidad.TabIndex = 23;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            label4.ForeColor = SystemColors.ButtonHighlight;
            label4.Location = new Point(700, 219);
            label4.Name = "label4";
            label4.Size = new Size(110, 31);
            label4.TabIndex = 22;
            label4.Text = "Cantidad";
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(830, 267);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(125, 35);
            btnAdd.TabIndex = 24;
            btnAdd.Text = "Agregar";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // dgvProductos
            // 
            dgvProductos.BackgroundColor = Color.Snow;
            dgvProductos.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvProductos.Columns.AddRange(new DataGridViewColumn[] { ID, Producto, Cantidad, Precio, Subtotal });
            dgvProductos.Location = new Point(136, 413);
            dgvProductos.Name = "dgvProductos";
            dgvProductos.RowHeadersWidth = 51;
            dgvProductos.RowTemplate.Height = 29;
            dgvProductos.Size = new Size(800, 220);
            dgvProductos.TabIndex = 25;
            // 
            // ID
            // 
            ID.HeaderText = "ID";
            ID.MinimumWidth = 6;
            ID.Name = "ID";
            ID.Width = 125;
            // 
            // Producto
            // 
            Producto.HeaderText = "Producto";
            Producto.MinimumWidth = 6;
            Producto.Name = "Producto";
            Producto.Width = 125;
            // 
            // Cantidad
            // 
            Cantidad.HeaderText = "Cantidad";
            Cantidad.MinimumWidth = 6;
            Cantidad.Name = "Cantidad";
            Cantidad.Width = 125;
            // 
            // Precio
            // 
            Precio.HeaderText = "Precio";
            Precio.MinimumWidth = 6;
            Precio.Name = "Precio";
            Precio.Width = 125;
            // 
            // Subtotal
            // 
            Subtotal.HeaderText = "Subtotal";
            Subtotal.MinimumWidth = 6;
            Subtotal.Name = "Subtotal";
            Subtotal.Width = 125;
            // 
            // lblTotalGeneral
            // 
            lblTotalGeneral.AutoSize = true;
            lblTotalGeneral.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
            lblTotalGeneral.ForeColor = SystemColors.ButtonHighlight;
            lblTotalGeneral.Location = new Point(700, 636);
            lblTotalGeneral.Name = "lblTotalGeneral";
            lblTotalGeneral.Size = new Size(61, 28);
            lblTotalGeneral.TabIndex = 26;
            lblTotalGeneral.Text = "$0.00";
            lblTotalGeneral.Click += lblTotalGeneral_Click;
            // 
            // button1
            // 
            button1.Location = new Point(487, 713);
            button1.Name = "button1";
            button1.Size = new Size(125, 35);
            button1.TabIndex = 27;
            button1.Text = "Registrar Venta";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // regVenta
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.DarkOliveGreen;
            ClientSize = new Size(1028, 958);
            Controls.Add(button1);
            Controls.Add(lblTotalGeneral);
            Controls.Add(dgvProductos);
            Controls.Add(btnAdd);
            Controls.Add(txtCantidad);
            Controls.Add(label4);
            Controls.Add(txtPrecio);
            Controls.Add(label3);
            Controls.Add(cmbProducto);
            Controls.Add(label2);
            Controls.Add(dtpFecha);
            Controls.Add(label1);
            Controls.Add(txtCliente);
            Controls.Add(label5);
            Controls.Add(label6);
            Name = "regVenta";
            Text = "regVenta";
            Load += regVenta_Load;
            ((System.ComponentModel.ISupportInitialize)dgvProductos).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label6;
        private Label label5;
        private TextBox txtCliente;
        private Label label1;
        private DateTimePicker dtpFecha;
        private Label label2;
        private ComboBox cmbProducto;
        private Label label3;
        private TextBox txtPrecio;
        private TextBox txtCantidad;
        private Label label4;
        private Button btnAdd;
        private DataGridView dgvProductos;
        private DataGridViewTextBoxColumn ID;
        private DataGridViewTextBoxColumn Producto;
        private DataGridViewTextBoxColumn Cantidad;
        private DataGridViewTextBoxColumn Precio;
        private DataGridViewTextBoxColumn Subtotal;
        private Label lblTotalGeneral;
        private Button button1;
    }
}