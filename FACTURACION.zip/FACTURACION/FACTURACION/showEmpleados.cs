﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace FACTURACION
{
    public partial class showEmpleados : Form
    {
        private ConexionBD conexionBD = new ConexionBD();
        public static string usuariobusqueda="";
        public showEmpleados()
        {
            InitializeComponent();
        }

        private void showEmpleados_Load(object sender, EventArgs e)
        {
            CargarEmpleados();
        }

        private void CargarEmpleados()
        {
            using (var conexion = conexionBD.ObtenerConexion())
            {
                string query = "SELECT idusuario, nombres, apellidos, telefono, direccion, cargo, usuario FROM usuario;";
                using (var comando = new MySqlCommand(query, conexion))
                {
                    DataTable dt = new DataTable();
                    MySqlDataAdapter adaptador = new MySqlDataAdapter(comando);
                    adaptador.Fill(dt);

                    dgvEmpleados.DataSource = dt;

                }
            }
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void btnir_Click(object sender, EventArgs e)
        {
            if (txtusuario.Text != null)
            {
                using (var conexion = conexionBD.ObtenerConexion())
                {
                    string query = "SELECT usuario FROM usuario WHERE usuario = @usuario";
                    using (var comando = new MySqlCommand(query, conexion))
                    {
                        comando.Parameters.AddWithValue("@usuario", txtusuario.Text);
                        using (var rdr = comando.ExecuteReader())
                        {
                            while (rdr.Read())
                            {
                                if (rdr.IsDBNull(0))
                                {
                                    MessageBox.Show("No existe empleado con ese nombre de usuario.");
                                }
                                else
                                {
                                    usuariobusqueda = rdr.GetString(0);
                                    var modempleado = new modempleado();
                                    modempleado.Show();
                                }
                            }
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Por favor ingrese un nombre de usuario");
            }
        }
    }

}
