﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FACTURACION
{
    public partial class misVentas : Form
    {
        private ConexionBD conexionBD = new ConexionBD();

        public misVentas()
        {
            InitializeComponent();
        }

        private void CargarVentasPorUsuarioYDia()
        {
            string query = @"
        SELECT
            DATE(FechaVenta) AS Fecha,
            SUM(Total) AS VentasTotales
        FROM
            Venta
        WHERE
            usuarioempleado = @NombreUsuarioActual
        GROUP BY
            DATE(FechaVenta);";

            using (var conexion = conexionBD.ObtenerConexion())
            {
                using (var comando = new MySqlCommand(query, conexion))
                {
                    comando.Parameters.AddWithValue("@NombreUsuarioActual", InformacionUsuario.NombreUsuario);

                    var adapter = new MySqlDataAdapter(comando);
                    var dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    dgvVentas.DataSource = dataTable; 
                }
            }
        }

        private void misVentas_Load(object sender, EventArgs e)
        {
            CargarVentasPorUsuarioYDia();
        }

    }
}
