﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FACTURACION
{
    public partial class modempleado : Form
    {
        private ConexionBD conexionBD = new ConexionBD();
        public modempleado()
        {
            InitializeComponent();
            using (var conexion = conexionBD.ObtenerConexion())
            {
                string query = "SELECT nombre FROM cargos;";
                using (var comando = new MySqlCommand(query, conexion))
                {
                    using (var rdr = comando.ExecuteReader())
                    {
                        while (rdr.Read())
                        {
                            for (int i = 0; i < rdr.FieldCount; i++)
                            {
                                cmbcargo.Items.Add(rdr.GetString(i));
                            }
                        }
                    }
                }
            }
            using (var conexion = conexionBD.ObtenerConexion())
            {
                string query = "SELECT idusuario, nombres, apellidos, telefono, direccion, cargo, usuario, pass FROM usuario WHERE usuario = @nombreusuario;";
                using (var comando = new MySqlCommand(query, conexion))
                {
                    comando.Parameters.AddWithValue("@nombreusuario", showEmpleados.usuariobusqueda);
                    using (var rdr = comando.ExecuteReader())
                    {
                        while (rdr.Read())
                        {
                            if (rdr.IsDBNull(1) == false)
                            {
                                txtnombre.Text = rdr.GetString(1);
                            }
                            if (rdr.IsDBNull(2) == false)
                            {
                                txtapellido.Text = rdr.GetString(2);
                            }
                            if (rdr.IsDBNull(3) == false)
                            {
                                txttelefono.Text = rdr.GetString(3);
                            }
                            if (rdr.IsDBNull(4) == false)
                            {
                                txtdireccion.Text = rdr.GetString(4);
                            }
                            if (rdr.IsDBNull(5) == false)
                            {
                                cmbcargo.Text = rdr.GetString(5);
                            }
                            if (rdr.IsDBNull(6) == false)
                            {
                                txtusuario.Text = rdr.GetString(6);
                            }
                            if (rdr.IsDBNull(7) == false)
                            {
                                txtpassword.Text = rdr.GetString(7);
                            }
                        }
                    }
                }
            }
            txtusuario.Enabled = false;
        }

        private void btncerrar_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("¿Está seguro de salir?, los cambios no guardados no tendrán efecto", "¿Está seguro de salir?", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void btnmodificar_Click(object sender, EventArgs e)
        {
            if (txtnombre.Text != "" && txtapellido.Text != "" && txttelefono.Text != "" && txtdireccion.Text != "" && cmbcargo.Text != "" && txtusuario.Text != "" && txtpassword.Text != "")
            {
                using (var conexion = conexionBD.ObtenerConexion())
                {
                    string query = "UPDATE usuario SET nombres=@nombre, apellidos=@apellido, telefono=@telefono, direccion=@direccion, cargo=@cargo, pass=@password WHERE usuario=@usuario";
                    using (var comando = new MySqlCommand(query, conexion))
                    {
                        comando.Parameters.AddWithValue("@nombre", txtnombre.Text);
                        comando.Parameters.AddWithValue("@apellido", txtapellido.Text);
                        comando.Parameters.AddWithValue("@telefono", txttelefono.Text);
                        comando.Parameters.AddWithValue("@direccion", txtdireccion.Text);
                        comando.Parameters.AddWithValue("@cargo", cmbcargo.Text);
                        comando.Parameters.AddWithValue("@usuario", txtusuario.Text);
                        comando.Parameters.AddWithValue("@password", txtpassword.Text);
                        try
                        {
                            comando.ExecuteNonQuery();
                            MessageBox.Show("Empleado registrado con éxito.");
                        }
                        catch (MySqlException ex)
                        {
                            MessageBox.Show("Error al registrar el empleado: " + ex.Message);
                        }
                        finally
                        {
                            conexionBD.CerrarConexion();
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Por favor complete todos los datos");
            }
        }

        private void cmbcargo_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
