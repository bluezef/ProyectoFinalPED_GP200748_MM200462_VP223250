﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FACTURACION
{
    public class Productos
    {
        public string Nombre { get; set; }
        public string Categoria { get; set; }

        public Productos(string nombre, string categoria)
        {
            Nombre = nombre;
            Categoria = categoria;
        }
    }
}
