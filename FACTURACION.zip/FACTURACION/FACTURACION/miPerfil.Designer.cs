﻿namespace FACTURACION
{
    partial class miPerfil
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblogopredmainadm = new Label();
            lblNombre = new Label();
            lblApellido = new Label();
            lblUsuario = new Label();
            SuspendLayout();
            // 
            // lblogopredmainadm
            // 
            lblogopredmainadm.Anchor = AnchorStyles.Bottom;
            lblogopredmainadm.BackColor = Color.Transparent;
            lblogopredmainadm.Font = new Font("Microsoft Sans Serif", 26.25F, FontStyle.Regular, GraphicsUnit.Point);
            lblogopredmainadm.ForeColor = Color.White;
            lblogopredmainadm.Location = new Point(265, 24);
            lblogopredmainadm.Margin = new Padding(4, 0, 4, 0);
            lblogopredmainadm.Name = "lblogopredmainadm";
            lblogopredmainadm.Size = new Size(487, 157);
            lblogopredmainadm.TabIndex = 2;
            lblogopredmainadm.Text = "Mi Perfil";
            lblogopredmainadm.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lblNombre
            // 
            lblNombre.AutoSize = true;
            lblNombre.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            lblNombre.ForeColor = SystemColors.ButtonHighlight;
            lblNombre.Location = new Point(169, 165);
            lblNombre.Name = "lblNombre";
            lblNombre.Size = new Size(112, 31);
            lblNombre.TabIndex = 15;
            lblNombre.Text = "Nombres";
            // 
            // lblApellido
            // 
            lblApellido.AutoSize = true;
            lblApellido.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            lblApellido.ForeColor = SystemColors.ButtonHighlight;
            lblApellido.Location = new Point(169, 234);
            lblApellido.Name = "lblApellido";
            lblApellido.Size = new Size(115, 31);
            lblApellido.TabIndex = 16;
            lblApellido.Text = "Apellidos";
            // 
            // lblUsuario
            // 
            lblUsuario.AutoSize = true;
            lblUsuario.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            lblUsuario.ForeColor = SystemColors.ButtonHighlight;
            lblUsuario.Location = new Point(169, 306);
            lblUsuario.Name = "lblUsuario";
            lblUsuario.Size = new Size(97, 31);
            lblUsuario.TabIndex = 17;
            lblUsuario.Text = "Usuario";
            // 
            // miPerfil
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.DarkOliveGreen;
            ClientSize = new Size(1028, 958);
            Controls.Add(lblUsuario);
            Controls.Add(lblApellido);
            Controls.Add(lblNombre);
            Controls.Add(lblogopredmainadm);
            Name = "miPerfil";
            Text = "miPerfil";
            Load += miPerfil_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblogopredmainadm;
        private Label lblNombre;
        private Label lblApellido;
        private Label lblUsuario;
    }
}