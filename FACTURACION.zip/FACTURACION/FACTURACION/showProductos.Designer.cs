﻿namespace FACTURACION
{
    partial class showProductos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label6 = new Label();
            dgvProductos = new DataGridView();
            label1 = new Label();
            btnir = new Button();
            txtcodigo = new TextBox();
            ((System.ComponentModel.ISupportInitialize)dgvProductos).BeginInit();
            SuspendLayout();
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI Black", 22.2F, FontStyle.Bold, GraphicsUnit.Point);
            label6.ForeColor = SystemColors.ButtonHighlight;
            label6.Location = new Point(354, 49);
            label6.Name = "label6";
            label6.Size = new Size(169, 41);
            label6.TabIndex = 14;
            label6.Text = "Productos";
            // 
            // dgvProductos
            // 
            dgvProductos.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvProductos.Enabled = false;
            dgvProductos.Location = new Point(68, 142);
            dgvProductos.Margin = new Padding(3, 2, 3, 2);
            dgvProductos.Name = "dgvProductos";
            dgvProductos.RowHeadersWidth = 51;
            dgvProductos.RowTemplate.Height = 29;
            dgvProductos.Size = new Size(687, 141);
            dgvProductos.TabIndex = 15;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            label1.ForeColor = Color.White;
            label1.Location = new Point(35, 652);
            label1.Name = "label1";
            label1.Size = new Size(614, 25);
            label1.TabIndex = 20;
            label1.Text = "Si desea modificar un producto, escriba el código y presione ir:";
            // 
            // btnir
            // 
            btnir.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            btnir.Location = new Point(773, 648);
            btnir.Name = "btnir";
            btnir.Size = new Size(75, 29);
            btnir.TabIndex = 22;
            btnir.Text = "Ir";
            btnir.UseVisualStyleBackColor = true;
            btnir.Click += btnir_Click_1;
            // 
            // txtcodigo
            // 
            txtcodigo.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            txtcodigo.Location = new Point(655, 650);
            txtcodigo.Name = "txtcodigo";
            txtcodigo.Size = new Size(63, 29);
            txtcodigo.TabIndex = 21;
            // 
            // showProductos
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.DarkOliveGreen;
            ClientSize = new Size(900, 718);
            Controls.Add(btnir);
            Controls.Add(txtcodigo);
            Controls.Add(label1);
            Controls.Add(dgvProductos);
            Controls.Add(label6);
            Margin = new Padding(3, 2, 3, 2);
            Name = "showProductos";
            Text = "showProductos";
            Load += showProductos_Load;
            ((System.ComponentModel.ISupportInitialize)dgvProductos).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label6;
        private DataGridView dgvProductos;
        private Label label1;
        private Button btnir;
        private TextBox txtcodigo;
    }
}