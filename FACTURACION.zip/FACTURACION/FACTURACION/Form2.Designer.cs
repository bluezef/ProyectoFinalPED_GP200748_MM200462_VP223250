﻿namespace FACTURACION
{
    partial class modempleado
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            txtnombre = new TextBox();
            txtapellido = new TextBox();
            txttelefono = new TextBox();
            txtdireccion = new TextBox();
            txtusuario = new TextBox();
            txtpassword = new TextBox();
            btncerrar = new Button();
            btnmodificar = new Button();
            cmbcargo = new ComboBox();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 27.75F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.White;
            label1.Location = new Point(34, 22);
            label1.Name = "label1";
            label1.Size = new Size(350, 42);
            label1.TabIndex = 0;
            label1.Text = "Perfil de Empleado";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            label2.ForeColor = Color.White;
            label2.Location = new Point(34, 122);
            label2.Name = "label2";
            label2.Size = new Size(104, 25);
            label2.TabIndex = 0;
            label2.Text = "Nombres:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            label3.ForeColor = Color.White;
            label3.Location = new Point(34, 308);
            label3.Name = "label3";
            label3.Size = new Size(102, 25);
            label3.TabIndex = 1;
            label3.Text = "Teléfono:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            label4.ForeColor = Color.White;
            label4.Location = new Point(34, 215);
            label4.Name = "label4";
            label4.Size = new Size(106, 25);
            label4.TabIndex = 2;
            label4.Text = "Apellidos:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            label5.ForeColor = Color.White;
            label5.Location = new Point(34, 403);
            label5.Name = "label5";
            label5.Size = new Size(108, 25);
            label5.TabIndex = 3;
            label5.Text = "Dirección:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            label6.ForeColor = Color.White;
            label6.Location = new Point(34, 502);
            label6.Name = "label6";
            label6.Size = new Size(76, 25);
            label6.TabIndex = 4;
            label6.Text = "Cargo:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            label7.ForeColor = Color.White;
            label7.Location = new Point(704, 122);
            label7.Name = "label7";
            label7.Size = new Size(92, 25);
            label7.TabIndex = 5;
            label7.Text = "Usuario:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            label8.ForeColor = Color.White;
            label8.Location = new Point(685, 215);
            label8.Name = "label8";
            label8.Size = new Size(129, 25);
            label8.TabIndex = 6;
            label8.Text = "Contraseña:";
            // 
            // txtnombre
            // 
            txtnombre.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold, GraphicsUnit.Point);
            txtnombre.Location = new Point(160, 116);
            txtnombre.Name = "txtnombre";
            txtnombre.Size = new Size(434, 35);
            txtnombre.TabIndex = 13;
            // 
            // txtapellido
            // 
            txtapellido.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold, GraphicsUnit.Point);
            txtapellido.Location = new Point(160, 209);
            txtapellido.Name = "txtapellido";
            txtapellido.Size = new Size(434, 35);
            txtapellido.TabIndex = 14;
            // 
            // txttelefono
            // 
            txttelefono.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold, GraphicsUnit.Point);
            txttelefono.Location = new Point(160, 302);
            txttelefono.Name = "txttelefono";
            txttelefono.Size = new Size(434, 35);
            txttelefono.TabIndex = 15;
            // 
            // txtdireccion
            // 
            txtdireccion.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold, GraphicsUnit.Point);
            txtdireccion.Location = new Point(160, 393);
            txtdireccion.Name = "txtdireccion";
            txtdireccion.Size = new Size(434, 35);
            txtdireccion.TabIndex = 16;
            // 
            // txtusuario
            // 
            txtusuario.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold, GraphicsUnit.Point);
            txtusuario.Location = new Point(662, 162);
            txtusuario.Name = "txtusuario";
            txtusuario.Size = new Size(181, 35);
            txtusuario.TabIndex = 18;
            // 
            // txtpassword
            // 
            txtpassword.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold, GraphicsUnit.Point);
            txtpassword.Location = new Point(662, 255);
            txtpassword.Name = "txtpassword";
            txtpassword.Size = new Size(181, 35);
            txtpassword.TabIndex = 19;
            txtpassword.UseSystemPasswordChar = true;
            // 
            // btncerrar
            // 
            btncerrar.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            btncerrar.Location = new Point(40, 618);
            btncerrar.Name = "btncerrar";
            btncerrar.Size = new Size(109, 37);
            btncerrar.TabIndex = 20;
            btncerrar.Text = "Cerrar";
            btncerrar.UseVisualStyleBackColor = true;
            btncerrar.Click += btncerrar_Click;
            // 
            // btnmodificar
            // 
            btnmodificar.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            btnmodificar.Location = new Point(704, 618);
            btnmodificar.Name = "btnmodificar";
            btnmodificar.Size = new Size(139, 37);
            btnmodificar.TabIndex = 22;
            btnmodificar.Text = "Modificar";
            btnmodificar.UseVisualStyleBackColor = true;
            // 
            // cmbcargo
            // 
            cmbcargo.Font = new Font("Microsoft Sans Serif", 18F, FontStyle.Bold, GraphicsUnit.Point);
            cmbcargo.FormattingEnabled = true;
            cmbcargo.Location = new Point(160, 496);
            cmbcargo.Name = "cmbcargo";
            cmbcargo.Size = new Size(434, 37);
            cmbcargo.TabIndex = 23;
            // 
            // modempleado
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.DarkOliveGreen;
            ClientSize = new Size(919, 667);
            Controls.Add(cmbcargo);
            Controls.Add(btnmodificar);
            Controls.Add(btncerrar);
            Controls.Add(txtpassword);
            Controls.Add(txtusuario);
            Controls.Add(txtdireccion);
            Controls.Add(txttelefono);
            Controls.Add(txtapellido);
            Controls.Add(txtnombre);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label1);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Name = "modempleado";
            Text = "eFactura: Perfil de empleado";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private TextBox txtnombre;
        private TextBox txtapellido;
        private TextBox txttelefono;
        private TextBox txtdireccion;
        private TextBox txtusuario;
        private TextBox txtpassword;
        private Button btncerrar;
        private Button btnborrar;
        private Button btnmodificar;
        private ComboBox cmbcargo;
    }
}