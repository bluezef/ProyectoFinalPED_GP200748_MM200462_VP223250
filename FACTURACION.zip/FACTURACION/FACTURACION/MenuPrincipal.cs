﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FACTURACION
{
    public partial class MenuPrincipal : Form
    {
        private ConexionBD conexionBD = new ConexionBD();
        
        public MenuPrincipal()
        {
            InitializeComponent();
            menulateraldesign();
        }


        private void menulateraldesign()
        {
            panelsubmenumostvent.Visible = false;
        }

        //Metodo que sirve para ocultar el submenu de ventas
        private void ocultarsubmenu()
        {
            if (panelsubmenumostvent.Visible == true)
                panelsubmenumostvent.Visible = false;
        }
        //Metodo que sirve para mostrar el submenu de ventas
        private void mostrarsubmenu(Panel submenu)
        {
            if (submenu.Visible == false)
                submenu.Visible = true;
            else submenu.Visible = false;
        }

        private void panelformularioactivo_Paint(object sender, PaintEventArgs e)
        {

        }

        private void AbrirFormularioHijo(Form formularioHijo)
        {
            if (panelformularioactivo.Controls.Count > 0)
                panelformularioactivo.Controls.RemoveAt(0);

            Form fh = formularioHijo;
            fh.TopLevel = false;
            fh.FormBorderStyle = FormBorderStyle.None;
            fh.Dock = DockStyle.Fill;
            panelformularioactivo.Controls.Add(fh);
            panelformularioactivo.Tag = fh;
            fh.Show();
        }


        private void btregprod_Click(object sender, EventArgs e)
        {
            AbrirFormularioHijo(new regProductos());
        }

        private void btmostprod_Click(object sender, EventArgs e)
        {

            AbrirFormularioHijo(new showProductos());

        }

        private void btregemp_Click(object sender, EventArgs e)
        {
            AbrirFormularioHijo(new regEmpleado());

        }

        private void btregvent_Click(object sender, EventArgs e)
        {

            AbrirFormularioHijo(new regVenta());

        }

        private void btmostemp_Click(object sender, EventArgs e)
        {

            AbrirFormularioHijo(new showEmpleados());

        }

        private void btmostventemp_Click(object sender, EventArgs e)
        {
            AbrirFormularioHijo(new ventaporEmpleado());

        }

        private void btmostventot_Click(object sender, EventArgs e)
        {
            AbrirFormularioHijo(new ventaporDia());

        }

        private void btmisvent_Click(object sender, EventArgs e)
        {
            AbrirFormularioHijo(new misVentas());

        }

        private void btmiperfil_Click(object sender, EventArgs e)
        {
            AbrirFormularioHijo(new miPerfil());

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();

            form1.Show();

            this.Close();
        }

        private void btsalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btmostvent_MouseEnter(object sender, EventArgs e)
        {
            mostrarsubmenu(panelsubmenumostvent);
        }

        private void btmostprod_MouseEnter(object sender, EventArgs e)
        {
            ocultarsubmenu();
        }

        private void button2_Click(object sender, EventArgs e)
        {
             Arbol arbol = new Arbol();
            using (var conexion = conexionBD.ObtenerConexion())
            {
                string query = "SELECT nombre, categoria FROM producto";
                using (var comando = new MySqlCommand(query, conexion))
                {
                    using (var rdr = comando.ExecuteReader())
                    {
                        while (rdr.Read())
                        {
                            for (int i = 0; i < rdr.FieldCount; i+=2)
                            {
                                var producto = new Productos(rdr.GetString(i), rdr.GetString(i + 1));
                                arbol.Agregar(producto);
                            }
                        }
                    }
                }
            }
            var formDibujoArbol = new showProductoClasificado(arbol.Raiz);
            formDibujoArbol.Show();
        }
    }
}
