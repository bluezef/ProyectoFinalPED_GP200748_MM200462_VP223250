﻿namespace FACTURACION
{
    partial class showEmpleados
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label6 = new Label();
            dgvEmpleados = new DataGridView();
            label1 = new Label();
            txtusuario = new TextBox();
            btnir = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvEmpleados).BeginInit();
            SuspendLayout();
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI Black", 22.2F, FontStyle.Bold, GraphicsUnit.Point);
            label6.ForeColor = SystemColors.ButtonHighlight;
            label6.Location = new Point(351, 36);
            label6.Name = "label6";
            label6.Size = new Size(178, 41);
            label6.TabIndex = 15;
            label6.Text = "Empleados";
            label6.Click += label6_Click;
            // 
            // dgvEmpleados
            // 
            dgvEmpleados.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvEmpleados.Enabled = false;
            dgvEmpleados.Location = new Point(28, 140);
            dgvEmpleados.Margin = new Padding(3, 2, 3, 2);
            dgvEmpleados.Name = "dgvEmpleados";
            dgvEmpleados.RowHeadersWidth = 51;
            dgvEmpleados.RowTemplate.Height = 29;
            dgvEmpleados.Size = new Size(833, 141);
            dgvEmpleados.TabIndex = 16;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            label1.ForeColor = Color.White;
            label1.Location = new Point(12, 664);
            label1.Name = "label1";
            label1.Size = new Size(650, 24);
            label1.TabIndex = 17;
            label1.Text = "Si desea modificar un empleado, escriba el nombre de usuario y presione ir:";
            // 
            // txtusuario
            // 
            txtusuario.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            txtusuario.Location = new Point(668, 666);
            txtusuario.Name = "txtusuario";
            txtusuario.Size = new Size(63, 29);
            txtusuario.TabIndex = 18;
            // 
            // btnir
            // 
            btnir.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            btnir.Location = new Point(786, 664);
            btnir.Name = "btnir";
            btnir.Size = new Size(75, 29);
            btnir.TabIndex = 19;
            btnir.Text = "Ir";
            btnir.UseVisualStyleBackColor = true;
            btnir.Click += btnir_Click;
            // 
            // showEmpleados
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.DarkOliveGreen;
            ClientSize = new Size(900, 718);
            Controls.Add(btnir);
            Controls.Add(txtusuario);
            Controls.Add(label1);
            Controls.Add(dgvEmpleados);
            Controls.Add(label6);
            Margin = new Padding(3, 2, 3, 2);
            Name = "showEmpleados";
            Text = "showEmpleados";
            Load += showEmpleados_Load;
            ((System.ComponentModel.ISupportInitialize)dgvEmpleados).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label6;
        private DataGridView dgvEmpleados;
        private Label label1;
        private TextBox txtusuario;
        private Button btnir;
    }
}