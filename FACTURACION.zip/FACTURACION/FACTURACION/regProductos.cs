﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FACTURACION
{
    public partial class regProductos : Form
    {
        private ConexionBD conexionBD = new ConexionBD();
        public regProductos()
        {
            InitializeComponent();
            using (var conexion = conexionBD.ObtenerConexion())
            {
                string query = "SELECT nombre FROM categoria;";
                using (var comando = new MySqlCommand(query, conexion))
                {
                    using (var rdr = comando.ExecuteReader())
                    {
                        while (rdr.Read())
                        {
                            for (int i = 0; i < rdr.FieldCount; i++)
                            {
                                cmbcategoria.Items.Add(rdr.GetString(i));
                            }
                        }
                    }
                }
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            if (txtCantidad.Text != "" && txtNombre.Text != "" && cmbcategoria.Text != "" && txtPrecio.Text != "")
            {
                string query = "INSERT INTO producto (nombre, descripcion, categoria, precio, cantidad_inventario) VALUES (@Nombre, @Descripcion, @Categoria, @Precio, @CantidadInventario)";

                using (var conexionBD = new ConexionBD())
                {
                    var conexion = conexionBD.ObtenerConexion();

                    using (var comando = new MySqlCommand(query, conexion))
                    {
                        comando.Parameters.AddWithValue("@Nombre", txtNombre.Text);
                        comando.Parameters.AddWithValue("@Descripcion", txtdescripcion.Text);
                        comando.Parameters.AddWithValue("@Categoria", cmbcategoria.Text);
                        comando.Parameters.AddWithValue("@Precio", txtPrecio.Text);
                        comando.Parameters.AddWithValue("@CantidadInventario", txtCantidad.Text);

                        try
                        {
                            comando.ExecuteNonQuery();
                            MessageBox.Show("Producto registrado con éxito.");
                        }
                        catch (MySqlException ex)
                        {
                            MessageBox.Show("Error al registrar el producto: " + ex.Message);
                        }
                        finally
                        {
                            conexionBD.CerrarConexion();
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Por favor complete todos los datos");
            }
        }

        private void btnBorrar_Click(object sender, EventArgs e)
        {
            txtNombre.Clear();
            txtdescripcion.Clear();
            cmbcategoria.SelectedIndex=0;
            txtPrecio.Clear();
            txtCantidad.Clear();
        }
    }
}
