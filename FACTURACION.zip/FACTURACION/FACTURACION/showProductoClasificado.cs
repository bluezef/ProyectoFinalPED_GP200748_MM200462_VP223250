﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FACTURACION
{
    public partial class showProductoClasificado : Form
    {

        private Nodo raiz;
        public showProductoClasificado(Nodo raiz)
        {
            InitializeComponent();
            this.raiz = raiz;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            if (raiz != null)
            {
                Pen lapiz = new Pen(Color.Black);
                Font fuente = new Font("Arial", 6);
                Brush relleno = new SolidBrush(Color.WhiteSmoke);
                Brush rellenoFuente = new SolidBrush(Color.Black);

                int xmin = 5;
                raiz.PosicionNodo(ref xmin, 10, 100, 0);

                raiz.DibujarRamas(e.Graphics, lapiz);

                raiz.DibujarNodo(e.Graphics, fuente, relleno, rellenoFuente, lapiz, relleno);
            }
        }
    }
}
