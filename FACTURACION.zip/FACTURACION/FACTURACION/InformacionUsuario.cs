﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FACTURACION
{
    internal static class InformacionUsuario
    {
        public static string NombreUsuario { get; private set; }

        public static void EstablecerUsuarioActual(string usuario)
        {
            NombreUsuario = usuario;
        }
    }
}
