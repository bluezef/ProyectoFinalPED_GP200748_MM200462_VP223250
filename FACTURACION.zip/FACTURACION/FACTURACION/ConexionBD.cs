﻿using System;
using MySql.Data.MySqlClient;

using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace FACTURACION
{
    internal class ConexionBD : IDisposable
    {

        private MySqlConnection conexion;

        public ConexionBD()
        {
            string servidor = "localhost";
            string db = "Facturacion";
            string usuario = "root";
            string password = "Root123!";
            string cadenaConexion = $"Server={servidor}; Database={db}; Uid={usuario}; Pwd={password};";

            conexion = new MySqlConnection(cadenaConexion);
        }

        public MySqlConnection ObtenerConexion()
        {
            try
            {
                conexion.Open();
                return conexion;
            }
            catch (MySqlException ex)
            {
                Console.WriteLine("Error al conectar a la base de datos: " + ex.Message);
                return null;
            }
        }

        public void CerrarConexion()
        {
            if (conexion != null && conexion.State == System.Data.ConnectionState.Open)
                conexion.Close();
        }

        public void Dispose()
        {
            CerrarConexion();
            conexion.Dispose();
        }
    }
}
