﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FACTURACION
{
    public partial class modProducto : Form
    {
        private ConexionBD conexionBD = new ConexionBD();
        public modProducto()
        {
            InitializeComponent();
            using (var conexion = conexionBD.ObtenerConexion())
            {
                string query = "SELECT nombre FROM categoria;";
                using (var comando = new MySqlCommand(query, conexion))
                {
                    using (var rdr = comando.ExecuteReader())
                    {
                        while (rdr.Read())
                        {
                            for (int i = 0; i < rdr.FieldCount; i++)
                            {
                                cmbcategoria.Items.Add(rdr.GetString(i));
                            }
                        }
                    }
                }
            }
            using (var conexion = conexionBD.ObtenerConexion())
            {
                string query = "SELECT nombre, precio, cantidad_inventario, categoria, descripcion FROM producto WHERE idproducto = @idproducto;";
                using (var comando = new MySqlCommand(query, conexion))
                {
                    comando.Parameters.AddWithValue("@idproducto", showProductos.codigobusqueda);
                    using (var rdr = comando.ExecuteReader())
                    {
                        while (rdr.Read())
                        {
                            if (rdr.IsDBNull(1) == false)
                            {
                                txtNombre.Text = rdr.GetString(1);
                            }
                            if (rdr.IsDBNull(2) == false)
                            {
                                txtPrecio.Text = rdr.GetString(2);
                            }
                            if (rdr.IsDBNull(3) == false)
                            {
                                txtCantidad.Text = rdr.GetString(3);
                            }
                            if (rdr.IsDBNull(4) == false)
                            {
                                cmbcategoria.Text = rdr.GetString(4);
                            }
                            if (rdr.IsDBNull(5) == false)
                            {
                                txtdescripcion.Text = rdr.GetString(5);
                            }
                        }
                    }
                }
            }
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            if (txtNombre.Text != "" && txtPrecio.Text != "" && cmbcategoria.Text != "" && txtdescripcion.Text != "" && txtCantidad.Text != "")
            {
                using (var conexion = conexionBD.ObtenerConexion())
                {
                    string query = "UPDATE producto SET nombre = @nombre, precio=@precio, categoria=@categoria, descripcion=@descripcion, cantidad_inventario=@cantidad_inventario WHERE idproducto = @idproducto;";
                    using (var comando = new MySqlCommand(query, conexion))
                    {
                        comando.Parameters.AddWithValue("@nombre", txtNombre.Text);
                        comando.Parameters.AddWithValue("@precio", txtPrecio.Text);
                        comando.Parameters.AddWithValue("@categoria", cmbcategoria.Text);
                        comando.Parameters.AddWithValue("@descripcion", txtdescripcion.Text);
                        comando.Parameters.AddWithValue("@cantidad_inventario", txtCantidad.Text);
                        comando.Parameters.AddWithValue("@idproducto", showProductos.codigobusqueda);
                        try
                        {
                            comando.ExecuteNonQuery();
                            MessageBox.Show("Empleado registrado con éxito.");
                        }
                        catch (MySqlException ex)
                        {
                            MessageBox.Show("Error al registrar el empleado: " + ex.Message);
                        }
                        finally
                        {
                            conexionBD.CerrarConexion();
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Por favor complete todos los datos");
            }
        }
    }
}
