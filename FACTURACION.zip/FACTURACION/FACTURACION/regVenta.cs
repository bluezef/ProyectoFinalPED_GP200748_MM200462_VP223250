﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FACTURACION
{
    public partial class regVenta : Form
    {
        private List<Producto> productos;
        decimal totalGeneral = 0;

        public regVenta()
        {

            InitializeComponent();
            CargarProductos();
            dgvProductos.AllowUserToAddRows = false;
        }

        private void regVenta_Load(object sender, EventArgs e)
        {

        }

        private void CargarProductos()
        {
            productos = ObtenerProductos();

            cmbProducto.DataSource = productos;
            cmbProducto.DisplayMember = "Nombre";
            cmbProducto.ValueMember = "ID";
        }
        private ConexionBD conexionBD = new ConexionBD();

        public int InsertarVenta(DateTime fechaVenta, string nombreCliente, decimal total, string nombreUsuarioEmpleado)
        {
            int ventaId = 0;
            string query = @"INSERT INTO Venta (FechaVenta, NombreCliente, Total, usuarioempleado) 
                     VALUES (@FechaVenta, @NombreCliente, @Total, @NombreUsuarioEmpleado); 
                     SELECT LAST_INSERT_ID();";

            using (var conexion = conexionBD.ObtenerConexion())
            {
                using (var comando = new MySqlCommand(query, conexion))
                {
                    comando.Parameters.AddWithValue("@FechaVenta", fechaVenta);
                    comando.Parameters.AddWithValue("@NombreCliente", nombreCliente);
                    comando.Parameters.AddWithValue("@Total", total);
                    comando.Parameters.AddWithValue("@NombreUsuarioEmpleado", nombreUsuarioEmpleado);

                    ventaId = Convert.ToInt32(comando.ExecuteScalar());
                }
            }

            return ventaId;
        }


        public bool InsertarDetalleVenta(int ventaId, int productoId, int cantidad, decimal precioUnitario)
        {
            string query = @"INSERT INTO DetalleVenta (VentaID, idproducto, Cantidad, PrecioUnitario, Subtotal) 
                         VALUES (@VentaID, @ProductoID, @Cantidad, @PrecioUnitario, @Subtotal);";

            decimal subtotal = cantidad * precioUnitario;
            try
            {
                using (var conexion = conexionBD.ObtenerConexion())
                {
                    using (var comando = new MySqlCommand(query, conexion))
                    {
                        comando.Parameters.AddWithValue("@VentaID", ventaId);
                        comando.Parameters.AddWithValue("@ProductoID", productoId);
                        comando.Parameters.AddWithValue("@Cantidad", cantidad);
                        comando.Parameters.AddWithValue("@PrecioUnitario", precioUnitario);
                        comando.Parameters.AddWithValue("@Subtotal", subtotal);
                        int result = comando.ExecuteNonQuery();
                        return result > 0;
                    }
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show("Ha ocurrido un error al registrar la venta: " + ex.Message);
                return false;
            }
        }

        internal List<Producto> ObtenerProductos()
        {
            List<Producto> productos = new List<Producto>();
            string query = "SELECT idproducto, nombre, precio, cantidad_inventario FROM producto;";

            using (var conexion = conexionBD.ObtenerConexion())
            {
                using (var comando = new MySqlCommand(query, conexion))
                {
                    using (var reader = comando.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            productos.Add(new Producto
                            {
                                ID = reader.GetInt32(0),
                                Nombre = reader.GetString(1),
                                Precio = reader.GetDecimal(2),
                                Cantidad = reader.GetInt32(3)

                            });
                        }
                    }
                }
            }

            return productos;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (cmbProducto.Text != "" && txtPrecio.Text != "" && txtCantidad.Text != "")
            {
                int idProducto = ((Producto)cmbProducto.SelectedItem).ID;
                string nombreProducto = ((Producto)cmbProducto.SelectedItem).Nombre;
                decimal precio = decimal.Parse(txtPrecio.Text);
                int cantidad = int.Parse(txtCantidad.Text);
                decimal subtotal = precio * cantidad;
                if (cantidad > ((Producto)cmbProducto.SelectedItem).Cantidad)
                {
                    MessageBox.Show("No hay suficientes existencias para la cantidad solicitada del producto.");
                    return;
                }

                DataGridViewRow newRow = new DataGridViewRow();
                newRow.CreateCells(dgvProductos);
                newRow.SetValues(idProducto, nombreProducto, cantidad, precio, subtotal);
                dgvProductos.Rows.Add(newRow);

                ActualizarTotalGeneral();
            }
            else
            {
                MessageBox.Show("Por favor complete todos los datos");
            }
        }
        private void cmbProducto_SelectedIndexChanged(object sender, EventArgs e)
        {
            Producto productoSeleccionado = (Producto)cmbProducto.SelectedItem;

            txtPrecio.Text = productoSeleccionado.Precio.ToString();
        }

        public bool ActualizarInventario(int productoId, int cantidadVendida)
        {
            string query = "UPDATE Producto SET cantidad_inventario = cantidad_inventario - @CantidadVendida WHERE idproducto = @ProductoID";

            using (var conexion = conexionBD.ObtenerConexion())
            {
                using (var comando = new MySqlCommand(query, conexion))
                {
                    comando.Parameters.AddWithValue("@CantidadVendida", cantidadVendida);
                    comando.Parameters.AddWithValue("@ProductoID", productoId);

                    int result = comando.ExecuteNonQuery();
                    return result > 0;
                }
            }
        }

        private void ActualizarTotalGeneral()
        {

            foreach (DataGridViewRow row in dgvProductos.Rows)
            {
                totalGeneral += Convert.ToDecimal(row.Cells["Subtotal"].Value);
            }

            lblTotalGeneral.Text = $"Total: {totalGeneral:C2}";
        }

        private void lblTotalGeneral_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string nombreCliente = txtCliente.Text;
            DateTime fechaVenta = dtpFecha.Value;
            string nomEmp = InformacionUsuario.NombreUsuario;

            int ventaId = InsertarVenta(fechaVenta, nombreCliente, totalGeneral, nomEmp);

            if (ventaId > 0)
            {
                foreach (DataGridViewRow row in dgvProductos.Rows)
                {
                    if (row.IsNewRow)
                        continue;
                    int productoId = Convert.ToInt32(row.Cells["ID"].Value);
                    int cantidad = Convert.ToInt32(row.Cells["Cantidad"].Value);
                    decimal precioUnitario = Convert.ToDecimal(row.Cells["Precio"].Value);
                    decimal subtotal = Convert.ToDecimal(row.Cells["Subtotal"].Value);

                    bool detalleInsertado = InsertarDetalleVenta(ventaId, productoId, cantidad, precioUnitario);
                    bool inventarioActualizado = ActualizarInventario(productoId, cantidad);

                    if (!detalleInsertado || !inventarioActualizado)
                    {
                        MessageBox.Show("Hubo un error al registrar los detalles de la venta o al actualizar el inventario.");
                        return;
                    }

                }

                MessageBox.Show("La venta ha sido registrada con éxito.");
            }
            else
            {
                MessageBox.Show("Hubo un error al registrar la venta.");
            }
        }
    }
}
