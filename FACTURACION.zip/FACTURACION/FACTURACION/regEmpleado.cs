﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FACTURACION
{
    public partial class regEmpleado : Form
    {
        private ConexionBD conexionBD = new ConexionBD();
        public regEmpleado()
        {
            InitializeComponent();
            using (var conexion = conexionBD.ObtenerConexion())
            {
                string query = "SELECT nombre FROM cargos;";
                using (var comando = new MySqlCommand(query, conexion))
                {
                    using (var rdr = comando.ExecuteReader())
                    {
                        while (rdr.Read())
                        {
                            for (int i = 0; i < rdr.FieldCount; i++)
                            {
                                cmbcargo.Items.Add(rdr.GetString(i));
                            }
                        }
                    }
                }
            }
        }

        private void regEmpleado_Load(object sender, EventArgs e)
        {

        }
        private void btnregistrar_Click(object sender, EventArgs e)
        {
            if (txtnombre.Text != "" && txtapellido.Text != "" && txttelefono.Text != "" && txtdireccion.Text != "" && cmbcargo.Text != "" && txtusuario.Text != "" && txtpassword.Text != "")
            {
                string query = "INSERT INTO usuario (nombres, apellidos, telefono, direccion, cargo, usuario, pass) VALUES (@nombre, @apellido, @telefono, @direccion, @cargo, @usuario, @password)";

                using (var conexionBD = new ConexionBD())
                {
                    var conexion = conexionBD.ObtenerConexion();

                    using (var comando = new MySqlCommand(query, conexion))
                    {
                        comando.Parameters.AddWithValue("@nombre", txtnombre.Text);
                        comando.Parameters.AddWithValue("@apellido", txtapellido.Text);
                        comando.Parameters.AddWithValue("@telefono", txttelefono.Text);
                        comando.Parameters.AddWithValue("@direccion", txtdireccion.Text);
                        comando.Parameters.AddWithValue("@cargo", cmbcargo.Text);
                        comando.Parameters.AddWithValue("@usuario", txtusuario.Text);
                        comando.Parameters.AddWithValue("@password", txtpassword.Text);

                        try
                        {
                            comando.ExecuteNonQuery();
                            MessageBox.Show("Empleado registrado con éxito.");
                        }
                        catch (MySqlException ex)
                        {
                            MessageBox.Show("Error al registrar el empleado: " + ex.Message);
                        }
                        finally
                        {
                            conexionBD.CerrarConexion();
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Por favor complete todos los datos");
            }
        }

        private void btnborrar_Click(object sender, EventArgs e)
        {
            txtnombre.Clear();
            txtapellido.Clear();
            txttelefono.Clear();
            txtdireccion.Clear();
            txtusuario.Clear();
            txtpassword.Clear();
        }

        private void btncerrar_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("¿Está seguro de salir?, los cambios no guardados no tendrán efecto", "¿Está seguro de salir?", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                this.Close();
            }
        }
    }
}
